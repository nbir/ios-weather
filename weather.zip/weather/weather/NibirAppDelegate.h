//
//  NibirAppDelegate.h
//  weather
//
//  Created by Nibir Bora on 12/4/13.
//  Copyright (c) 2013 Nibir Bora. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NibirAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
