//
//  main.m
//  weather
//
//  Created by Nibir Bora on 12/4/13.
//  Copyright (c) 2013 Nibir Bora. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NibirAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([NibirAppDelegate class]));
    }
}
